/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.colas_libreria;

/**
 *
 * @author pipex
 */
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Deque;
import java.util.PriorityQueue;

public class Colas_Libreria {

    public static void main(String[] args) {
        System.out.println("Ejercicios Colas con libreria de JAVA\n");
        Colasimple(); 
        ColasCircular();
        ColasPrioridad();
        ColasDoble();
    }
    
    static void Colasimple(){
    System.out.println("Ejerccicio Colas Simple:primero en llegar primero en salir (FIF0) \n");
    
    Queue<String> java = new ArrayDeque<>();
    java.offer("ANA");
    java.offer("VIVIANA");
    java.offer("LEINER");
    System.out.println("Java :  " + java.poll() + ", " + java.poll()+ "\n" );
}
    static void ColasCircular(){
    System.out.println("Ejerccicio Colas Simple:reutiliza los espacios del arreglo \n");
    
    Queue<String> java = new ArrayDeque<>();
    java.offer("ANA");
    java.offer("VIVIANA");
    java.offer("LEINER");
    System.out.println("SALE :  " + java.poll());
    java.offer("FABIO");
    System.out.println("Java :  " + java.poll() + ", " + java.poll() + ", " + java.poll() + "\n");
}
    
    static void ColasPrioridad(){
    System.out.println("Ejerccicio Colas Prioridad:el menor numero de atiende primero");
    
    Queue<Integer> java = new PriorityQueue<>();
    java.offer(5);
    java.offer(2);
    java.offer(3);
    System.out.println("Java :  " + java.poll() + ", " + java.poll() + ", " + java.poll()+ "\n" );
    }
    
    static void ColasDoble(){
    System.out.println("Colas Doble(DEQUE):Permite usar ambos extremos \n");
    
    Deque<String> java = new ArrayDeque<>();
    java.offerLast("ANA");
    java.offerLast("VIVIANA");
    java.offerFirst("LEINER");
    System.out.println("Java : Sale del Inicio " + java.pollFirst() + ", Sale del Final " + java.pollLast());
    }
}
